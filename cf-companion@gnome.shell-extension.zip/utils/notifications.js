// utils/notifications.js
// Handles sending GNOME desktop notifications for contest reminders.
//
// The tricky part: we only want each notification to fire once.
// If GNOME Shell restarts, we don't want it to spam every reminder again.
// We track which notifications have been sent using a Set keyed by
// "<contestId>-<type>" (e.g. "1234-1h", "1234-15m", "1234-start").
//
// This Set lives in memory, so it resets on Shell restart — which means
// on a fresh session the user might see one round of catch-up notifications.
// That's acceptable and matches what most reminder apps do.

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as MessageTray from 'resource:///org/gnome/shell/ui/messageTray.js';

// Tracks which (contestId, type) pairs have already been notified this session.
const sentNotifications = new Set();

let _notificationSource = null;

function getSource() {
    // MessageTray.Source is reused across notifications — one source per extension.
    if (_notificationSource === null) {
        _notificationSource = new MessageTray.Source({
            title: 'CF Companion',
            iconName: 'trophy-gold-symbolic',
        });
        Main.messageTray.add(_notificationSource);
    }
    return _notificationSource;
}

/**
 * Sends a desktop notification if it hasn't been sent yet this session.
 *
 * @param {string} key   - Unique key, e.g. "1234-1h". Prevents duplicates.
 * @param {string} title - Notification title.
 * @param {string} body  - Notification body text.
 */
export function notify(key, title, body) {
    if (sentNotifications.has(key)) return;
    sentNotifications.add(key);

    try {
        const source = getSource();
        const notification = new MessageTray.Notification({
            source,
            title,
            body,
        });
        source.addNotification(notification);
    } catch (err) {
        console.error(`[CF Companion] Notification failed: ${err.message}`);
    }
}

/**
 * Checks all upcoming contests and fires any due reminders.
 * Called every minute by the countdown timer.
 *
 * @param {Array} contests - Array of contest objects from the CF API.
 */
export function checkReminders(contests, enabled = true) {
    if (!enabled) return;

    const nowSeconds = Math.floor(Date.now() / 1000);

    for (const contest of contests) {
        const secondsLeft = contest.startTimeSeconds - nowSeconds;

        if (secondsLeft > 3540 && secondsLeft <= 3660) {
            notify(`${contest.id}-1h`, '⏰ Contest in 1 hour', contest.name);
        }

        if (secondsLeft > 840 && secondsLeft <= 960) {
            notify(`${contest.id}-15m`, '🔔 Contest in 15 minutes!', contest.name);
        }

        if (secondsLeft > -60 && secondsLeft <= 0) {
            notify(`${contest.id}-start`, '🚀 Contest started!', contest.name);
        }
    }
}

/**
 * Cleans up the notification source on extension disable.
 * This prevents a dangling source in the message tray.
 */
export function destroySource() {
    if (_notificationSource !== null) {
        try {
            _notificationSource.destroy();
        } catch (err) {
            console.error(`[CF Companion] Notification cleanup failed: ${err.message}`);
        }
        _notificationSource = null;
    }
    sentNotifications.clear();
}
