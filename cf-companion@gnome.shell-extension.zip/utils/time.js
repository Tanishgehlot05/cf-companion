// utils/time.js
// Small helpers for formatting time differences.
// Kept separate so extension.js doesn't get cluttered with string arithmetic.

/**
 * Returns how many seconds remain until `startTimeSeconds`.
 * Negative if the contest has already started.
 */
export function secondsUntil(startTimeSeconds) {
    const nowSeconds = Math.floor(Date.now() / 1000);
    return startTimeSeconds - nowSeconds;
}

/**
 * Formats a remaining-seconds value into a short human string.
 * Used for the panel label ("CF • 2h 14m") and menu rows.
 *
 *   86500  → "1d 0h"
 *   7320   → "2h 2m"
 *   90     → "1m"
 *   0      → "now"
 *   -60    → "now"  (treat anything past as "now" — it'll refresh soon)
 */
export function formatCountdown(seconds) {
    if (seconds <= 0) return 'now';

    const days  = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const mins  = Math.floor((seconds % 3600) / 60);

    if (days > 0) return `${days}d ${hours}h`;
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
}

/**
 * Formats a contest start time for display in the dropdown.
 * Example: "Mon, 28 Apr · 18:35"
 */
export function formatStartDate(startTimeSeconds) {
    const date = new Date(startTimeSeconds * 1000);
    return date.toLocaleString([], {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
}

/**
 * Formats contest duration (in seconds) as "Xh Ym".
 * Example: 9000 → "2h 30m"
 */
export function formatDuration(durationSeconds) {
    const hours = Math.floor(durationSeconds / 3600);
    const mins  = Math.floor((durationSeconds % 3600) / 60);
    return `${hours}h ${mins}m`;
}

/**
 * Returns a CSS class name based on how soon the contest starts.
 * These map to colors defined in stylesheet.css.
 *
 *  > 24h  → 'cf-urgency-green'
 *  6–24h  → 'cf-urgency-yellow'
 *  1–6h   → 'cf-urgency-orange'
 *  < 1h   → 'cf-urgency-red'
 */
export function urgencyClass(seconds) {
    if (seconds > 24 * 3600) return 'cf-urgency-green';
    if (seconds > 6 * 3600)  return 'cf-urgency-yellow';
    if (seconds > 3600)      return 'cf-urgency-orange';
    return 'cf-urgency-red';
}
